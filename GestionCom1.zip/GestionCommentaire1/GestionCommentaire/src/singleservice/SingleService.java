/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singleservice;

import Entite.Comment;
import Service.ServiceComment;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
            
/**
 *
 * @author sana
 */
public class SingleService {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {
        
         //  java.util.Date utilDate;
         // utilDate = new SimpleDateFormat("yyyy-MM-dd").parse("2019-04-20");
         // java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

//      String oldstring = "2011-01-18 00:00:00.0";
//      LocalDateTime datetime = LocalDateTime.parse(oldstring, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S"));
        Comment c1=new Comment(1,12,100,"20/04/2019","Hello");//sqlDate
        ServiceComment service=new ServiceComment();
        
        
        try {
            service.ajouterComment(c1);
        } catch (SQLException ex) {
            System.out.println(ex);  
        }
        
        List<Comment> list1=null;
        
        
        try {
            list1=service.readAll();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
         Comment c2=new Comment(1,50,200,"20/03/2019","Hi, Aya");//sqlDate

         
        try {
            service.ajouterComment2(c2);
        } catch (SQLException ex) {
            System.out.println(ex);  
        }
        
        System.out.println(list1);
    }
    
}
