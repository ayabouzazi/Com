/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import Entite.Comment;
import Service.ServiceComment;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class AjoutComController implements Initializable {

    @FXML
    private TextField tfUser_ID;
    @FXML
    private TextField tfDate;
    @FXML
    private TextArea tfContent;
    @FXML
    private TextField tfPublication_ID;
    @FXML
    private Button tfSave;
    @FXML
    private Button tfValid;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ActionSave(ActionEvent event) throws MalformedURLException, IOException {
        
        Comment c = new Comment();
        c.setUser_ID(Integer.valueOf(tfUser_ID.getText()));
        c.setPublication_ID(Integer.valueOf(tfPublication_ID.getText()));
        c.setComment_date(tfDate.getText());
        c.setContent(tfContent.getText());
        ServiceComment com = new ServiceComment();
        try {
            com.ajouterComment(c);
        } catch (SQLException ex) {
            Logger.getLogger(AjoutComController.class.getName()).log(Level.SEVERE, null, ex);
        }
       

    }

    @FXML
    private void ActionValid(ActionEvent event) throws MalformedURLException, IOException {
        URL url = new File("C:\\Users\\Lenovo\\Documents\\NetBeansProjects\\GestionCommentaire\\src\\Gui\\AfficheCom.fxml").toURI().toURL();
        Parent root = FXMLLoader.load(url);
        tfSave.getScene().setRoot(root); 
    }
   
}

