/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class PublicationController implements Initializable {

    @FXML
    private ImageView tfphoto;
    @FXML
    private Label tftitle;
    @FXML
    private Button tfComment;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ActionComment(ActionEvent event) throws MalformedURLException, IOException {
        
        URL url = new File("C:\\Users\\Lenovo\\Documents\\NetBeansProjects\\GestionCommentaire\\src\\gui\\AjoutCom.fxml").toURI().toURL();
        Parent root = FXMLLoader.load(url);
        tfComment.getScene().setRoot(root);
        
    }
    
}
