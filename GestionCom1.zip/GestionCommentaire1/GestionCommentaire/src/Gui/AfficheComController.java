/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import Entite.Comment;
import Service.ServiceComment;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class AfficheComController implements Initializable {

    @FXML
    private TableView<Comment> tfview;
    @FXML
    private TableColumn<Comment,Number> tfUser_ID;
    @FXML
    private TableColumn<Comment,Number> tfPublication_ID;
    @FXML
    private TableColumn<Comment, String> tfContent;
    @FXML
    private TableColumn<Comment, String> tfComment_Date;
    private ObservableList<Comment>data = FXCollections.observableArrayList();
    List<Comment> st = new ArrayList<>();
    @FXML
    private TableColumn<?, ?> tfComment_ID;
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ServiceComment c = new ServiceComment();
        try{
            st=c.readAll();
            data.addAll(st);
            
            tfPublication_ID.setCellValueFactory(new PropertyValueFactory<>("Publication_ID"));
            tfContent.setCellValueFactory(new PropertyValueFactory<>("Content"));
            tfComment_Date.setCellValueFactory(new PropertyValueFactory<>("Comment_Date"));
          //  tfUser_ID.setCellValueFactory(new PropertyValueFactory<>("User_ID"));

            tfview.setItems(data);
            
        } catch (SQLException ex) {
            Logger.getLogger(AfficheComController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void ModDel(MouseEvent event) throws MalformedURLException, IOException {
        
        URL url = new File("C:\\Users\\Lenovo\\Documents\\NetBeansProjects\\GestionCommentaire\\src\\gui\\ModDel.fxml").toURI().toURL();
        Parent root = FXMLLoader.load(url);
        tfview.getScene().setRoot(root);
        
    }
    
}
