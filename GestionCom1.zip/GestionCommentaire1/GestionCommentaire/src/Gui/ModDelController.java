/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import Entite.Comment;
import Service.ServiceComment;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class ModDelController implements Initializable {

    @FXML
    private Button tfDelete;
    @FXML
    private Button tfUpdate;
    @FXML
    private Button tfReturn;
    @FXML
    private TextField tfCom_ID;
    @FXML
    private TextArea tfContent;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ActionDelete(ActionEvent event) {
    }

    @FXML
    private void ActionUpdate(ActionEvent event) throws IOException, SQLException {
        
//        Comment c = new Comment();
//         c.setComment_ID(Integer.valueOf(tfCom_ID.getText()));
//         c.setContent(tfContent.getText());
//
//        
//         ServiceComment ce;
//         ce = new ServiceComment();
//         ce.updateComment(c);
//        
//        Parent root = FXMLLoader.load(getClass().getResource("/AfficheCom.fxml"));
//        Scene scene = new Scene(root);
//        Stage stage = new Stage();
//        stage.setScene(scene);
//        stage.show();
//        ((Node) (event.getSource())).getScene().getWindow().hide();

        Comment c = new Comment();
        c.setComment_ID(Integer.valueOf(tfCom_ID.getText()));
        c.setContent(tfContent.getText());
        
        ServiceComment sc = new ServiceComment();
        try {
            sc.UpdateComment(c.getComment_ID(),c.getContent());
        } catch (SQLException ex) {
            Logger.getLogger(ModDelController.class.getName()).log(Level.SEVERE, null, ex);
        }
        URL url = new File("C:\\Users\\Lenovo\\Documents\\NetBeansProjects\\GestionCommentaire\\src\\gui\\AfficheCom.fxml").toURI().toURL();
        Parent root = FXMLLoader.load(url);
        tfUpdate.getScene().setRoot(root);   
    }

    @FXML
    private void ActionReturn(ActionEvent event) {
    }
    
}
