/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import java.sql.Date;

/**
 *
 * @author Lenovo
 */
public class Comment {
    private int Comment_ID;
    private int User_ID;
    private int Publication_ID;
    private String Comment_Date;
    private String Content;

    public Comment() {
    }

    
    
    public Comment(int Comment_ID, int User_ID, int Publication_ID, String Comment_Date, String Content) {
        this.Comment_ID = Comment_ID;
        this.User_ID = User_ID;
        this.Publication_ID = Publication_ID;
        this.Comment_Date = Comment_Date;
        this.Content = Content;
    }

  
    
    

    public int getComment_ID() {
        return Comment_ID;
    }

    public void setComment_ID(int Comment_ID) {
        this.Comment_ID = Comment_ID;
    }
    

    public int getUser_ID() {
        return User_ID;
    }

    public void setUser_ID(int User_ID) {
        this.User_ID = User_ID;
    }

    public int getPublication_ID() {
        return Publication_ID;
    }

    public void setPublication_ID(int Publication_ID) {
        this.Publication_ID = Publication_ID;
    }

    public String getComment_Date() {
        return Comment_Date;
    }

    public void setComment_date(String Comment_Date) {
        this.Comment_Date = Comment_Date;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String Content) {
        this.Content = Content;
    }


    @Override
    public String toString() {
        return "Comments{" + "Comment_ID=" + Comment_ID + ", User_ID=" + User_ID + ", Publication_ID=" + Publication_ID + ", Comment_Date=" + Comment_Date + ", Content=" + Content + '}';
    }

    
}
