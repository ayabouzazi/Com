/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entite.Comment;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import utils.DataSource;
import java.sql.Date;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class ServiceComment {
       private Connection con = DataSource.getInstance().getConnection();
       private Statement ste;

    public ServiceComment() {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            System.out.println(ex);  
        }
    }

    public void ajouterComment(Comment c) throws SQLException{
      String requete = "INSERT INTO `comments` (`Comment_ID`, `User_ID`, `Publication_ID`,`Comment_Date`,`Content`) "
              + "VALUES (NULL, '"+c.getUser_ID()+"', '"+c.getPublication_ID()+"','"+c.getComment_Date()+"','"+c.getContent()+"');";
   ste.executeUpdate(requete);
        System.out.println("comment inserted");
    }
    public List<Comment> readAll() throws SQLException
    {List<Comment> list=new ArrayList<>();
    ResultSet res=ste.executeQuery("select * from comments");
    Comment com=null;
    while (res.next()) {            
      com=new Comment(res.getInt(1), res.getInt(5),res.getInt(4),res.getString(2),res.getString(3));
      list.add(com);
        }
    return list;
    } 
  public void ajouterComment2(Comment c) throws SQLException{  
  String req="INSERT INTO `Comments` ( `User_ID`, `Publication_ID`,`Comment_Date`, `Content`) VALUES (?,?,?,?)";
  PreparedStatement cres=con.prepareStatement(req);
  cres.setInt(1, c.getUser_ID());
  cres.setString(2, c.getComment_Date());
  cres.setString(1, c.getContent());
  
  cres.executeUpdate();
      System.out.println("comment inserted");
  
  }
 public void modificationComment(int Comment_ID) throws SQLException{
     String requete = "UPDATE 'Comments' SET 'Content'='commentaire ' WHERE 'comment'.'Comment_id'='" + Comment_ID + "'; ";
     ste.executeUpdate(requete);
     System.out.println("comment modified");
     
 }
 
 
     public void UpdateComment(int Comment_ID, String Content) throws SQLException{
         try
    {
     
      String query = "UPDATE Comments SET Content=? WHERE Comment_ID=?";
      PreparedStatement statement = con.prepareStatement(query);
      statement.setString(3,Content);
      
      
      statement.setInt(5, Comment_ID);

      // execute the java preparedstatement
      statement.executeUpdate();
      
    }
    catch (Exception e)
    {
      System.err.println("Got an exception! ");
      System.err.println(e.getMessage());
    }
    }
 
 
 public void supprimerComment(int Comment_ID) throws SQLException{
     String requete = "DELETE FROM 'Comments' WHERE 'Comments'.'Comment_id'= " + Comment_ID + " ";
     ste.executeUpdate(requete);
     System.out.println("comment deleted");
             }
     public void deleteComment(int Comment_ID) throws SQLException{
        String req="DELETE FROM `comments` WHERE Comment_ID = ?";
        try{PreparedStatement preparedStmt = con.prepareStatement(req);
        preparedStmt.setInt(1, Comment_ID);
        preparedStmt.execute();
        } catch (Exception e)
        {
          System.err.println("Got an exception! ");
          System.err.println(e.getMessage());
        }
    }
  
}
